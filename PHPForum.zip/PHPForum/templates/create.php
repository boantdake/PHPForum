<?php include('includes/header.php'); ?>
<!--Create Topic Template  -->
<form role="form">
              <div class="form-group">
                <label>Topic Title</label>
                <input type="text" name="title" class="form-control" placeholder="Enter Post Title">
              </div>
              <div class="form-group">
                <label>Category</label>
                <select class="form-control">
                  <option>Design</option>
                  <option>Development</option>
                  <option>Business and Marketing</option>
                  <option>Search Engines</option>
                  <option>Cloud and Hosting</option>
                </select>
              </div>
              <div class="form-group">
                <label>Topic Body</label>
                <textarea id="body" name="body" rows="10" cols="80" class="form-control" placeholder="Describe Your Topic"></textarea>
                <script>CKEDITOR.replace('body');</script>
              </div>
              <button type="submit" class="btn btn-primary">Submit</button>

            </form>


<?php include('includes/footer.php'); ?>