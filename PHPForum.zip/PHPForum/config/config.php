<?php 

	//DB Params
	define("DB_HOST", "localhost");
	define("DB_USER", "root");
	define("DB_PASS", "jackass9");
	define("DB_NAME", "phpforum");

	define("SITE_TITLE", "Dake Development PHP Forum");

	//paths
	define('BASE_URI', 'http://'.$_SERVER['SERVER_NAME'].'/PHPForum/');